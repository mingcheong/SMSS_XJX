function getUrlStr() {
	var addr = window.location.href;
	var pos = addr.lastIndexOf("_");
	if (pos < 0) {
		return "";
	}
	return addr.substring(0, pos);
}
function getBaseUrl() {
	var addr = window.location.href;
	var pos2 = addr.lastIndexOf("/");
	if (pos2 < 0) {
		return "";
	}
	return addr.substring(0, pos2 + 1);
}
/**
 * 获取命名空间
 * 
 * @return {String}
 */
function getNameSpaceStr() {
	var addr = window.location.href;
	var pos = addr.lastIndexOf("_");
	if (pos < 0) {
		return "";
	}
	var pos2 = addr.lastIndexOf("/");
	return addr.substring(pos2 + 1, pos);
}
function validateAddr(addr) {
	if (addr.length == 0) {
		alert("当前url不支持此操作");
		return false;
	}
	return true;
}
/**
 * CRUD操作对象,可以设置CRUD的拦截函数
 */
function Operator() {
	this.formId = "submitForm";
	this.baseUrl = getBaseUrl();
	this.addr = getNameSpaceStr();
	this.params = "";
	this.validate = true;
}
Operator.prototype = {
	beforeCreate : null,
	/**
	 * 初始化保存页面
	 */
	create : function() {
		if (this.beforeCreate)
			if (!this.beforeCreate())
				return;
		if (validateAddr(this.addr)) {
			var href = this.baseUrl + this.addr + "_create.xhtml" + this.params;
			window.location.href = href;
		}
	},

	beforeSave : null,
	/**
	 * 保存或更新实体
	 * 
	 * @param {}
	 *            id
	 */
	save : function(id) {
		if (formValidator.validate()) {
			if (this.beforeSave)
				if (!this.beforeSave())
					return;
			if (validateAddr(this.addr)) {
				var href = this.baseUrl + this.addr + "_save.xhtml"
						+ this.params;
				jQuery("#" + this.formId).attr("action", href).submit();
			}
		}
	},

	beforeUpdate : null,
	/**
	 * 初始化更新页面
	 * 
	 * @param {}
	 *            id
	 */
	update_single : function(id) {
		if (this.beforeUpdate)
			if (!this.beforeUpdate())
				return;
		if (validateAddr(this.addr)) {
			var href = this.baseUrl + this.addr + "_update.xhtml?entity.id="
					+ id + this.params;
			window.location.href = href;
		}
	},
	/**
	 * 初始化更新页面
	 * 
	 * @param {}
	 *            id
	 */
	update : function(id) {
		if (formValidator.validate()) {
			if (this.beforeUpdate)
				if (!this.beforeUpdate())
					return;
			if (validateAddr(this.addr)) {
				var ids = document.getElementsByName("ids");
				if (ids == null || ids.length == 0) {
					return;
				}
				var n = 0;
				var id = 0;
				for (var i = 0; i < ids.length; i++) {
					if (ids[i].checked) {
						n++;
						id = ids[i].value;
					}
				}
				if (n > 1 || id <= 0) {
					alert("请选择一条数据");
					return;
				}
				var href = this.baseUrl + "_update.xhtml?entity.id=" + id
						+ this.params;
				window.location.href = href;
			}
		}
	},

	beforeDelete : null,
	deleteAll_single : function(id) {
		if (this.beforeDelete)
			if (!this.beforeDelete())
				return;
		if (validateAddr(this.addr)) {
			var href = this.baseUrl + this.addr + "_delete.xhtml?ids=" + id
					+ this.params;
			if (window.confirm("确定是否要删除数据？"))
				window.location.href = href;
		}
	},
	/**
	 * 可以用于批量更新操作
	 * 
	 * @param {}
	 *            method
	 */
	deleteAll : function(method) {
		if (this.beforeDelete)
			if (!this.beforeDelete())
				return;
		if (validateAddr(this.addr)) {
			var ids = document.getElementsByName("ids");
			if (ids == null || ids.length == 0) {
				return;
			}
			var idArray = new Array();
			for (var i = 0; i < ids.length; i++) {
				if (ids[i].checked) {
					idArray.push(ids[i].value.trim());
				}
			}
			if (idArray.length == 0) {
				alert("请选择要删除的数据");
				return;
			}
			var str = "确定是否要删除数据？";
			if (method == null || method == 'undefined') {
				method = "delete";
			}
			var href = this.baseUrl + this.addr + "_" + method + ".xhtml?ids="
					+ idArray.join(",") + this.params;
			if (method == "delete") {
				if (window.confirm(str))
					window.location.href = href;
			} else {
				window.location.href = href;
			}
		}
	},

	beforeLocation : null,
	/**
	 * 跳转URL
	 * 
	 * @param {}
	 *            url
	 */
	location : function(url) {
		if (this.beforeLocation)
			if (!this.beforeLocation())
				return;
		var ids = document.getElementsByName("ids");
		if (ids == null || ids.length == 0) {
			return;
		}
		var n = 0;
		var id = 0;
		for (var i = 0; i < ids.length; i++) {
			if (ids[i].checked) {
				n++;
				id = ids[i].value.trim();
			}
		}
		if (n > 1 || id <= 0) {
			alert("请选择一条数据");
			return;
		}
		var href = this.baseUrl + url + id;
		window.location.href = href;
	},
	director : function(url) {
		window.location.href = url;
	},
	reload : function() {
		window.location.reload();
	},
	back : function(i) {
		window.history.back(i);
	}
}
function save(id, url) {
	if (formValidator.validate()) {
		var form = "submitForm"
		var addr = getUrlStr();
		if (addr.length == 0) {
			alert("当前url不支持此操作");
			return;
		}
		addr += "_save.xhtml";
		if (id != null && id != 'undefined' && id != "") {
			form = id;
		}
		if (url != null && url != 'undefined' && url != "") {
			addr = url;
		}
		jQuery("#" + form).attr("action", addr).submit();
	}
}
function create() {
	var addr = getUrlStr();
	if (addr.length == 0) {
		alert("当前url不支持此操作");
		return;
	}

	addr += "_create.xhtml";

	window.location.href = addr;
}

function update() {
	if (formValidator.validate()) {
		var addr = getUrlStr();
		if (addr.length == 0) {
			alert("当前url不支持此操作");
			return;
		}
		var ids = document.getElementsByName("ids");
		if (ids == null || ids.length == 0) {
			return;
		}
		var n = 0;
		var id = 0;
		for (var i = 0; i < ids.length; i++) {
			if (ids[i].checked) {
				n++;
				id = ids[i].value;
			}

		}
		if (n > 1 || id <= 0) {
			alert("请选择一条数据进行修改");
			return;
		}

		addr += "_update.xhtml?entity.id=" + id;
		window.location.href = addr;
	}
}

function update_single(id) {
	var addr = getUrlStr();
	addr += "_update.xhtml?entity.id=" + id;
	window.location.href = addr;
}

function deleteAll() {
	var addr = getUrlStr();
	if (addr.length == 0) {
		alert("当前url不支持此操作");
		return;
	}

	var ids = document.getElementsByName("ids");
	if (ids == null || ids.length == 0) {
		return;
	}
	var idArray = new Array();
	for (var i = 0; i < ids.length; i++) {
		if (ids[i].checked) {
			idArray.push(ids[i].value);
		}

	}
	if (idArray.length == 0) {
		alert("请选择要删除的数据");
		return;
	}

	addr += "_delete.xhtml?ids=" + idArray.join(",");
	if (window.confirm("确定是否要删除数据？"))
		window.location.href = addr;
}

function deleteAll_single(id) {
	var addr = getUrlStr();
	addr += "_delete.xhtml?ids=" + id;
	if (window.confirm("确定是否要删除数据？"))
		window.location.href = addr;
}

function delete_single(id,param) {
	var addr = getUrlStr();
	addr += "_delete.xhtml?ids=" + id + param;
	if (window.confirm("确定是否要删除数据？"))
		window.location.href = addr;
}

function view() {
		var addr = getUrlStr();
		if (addr.length == 0) {
			alert("当前url不支持此操作");
			return;
		}
		var ids = document.getElementsByName("ids");
		if (ids == null || ids.length == 0) {
			return;
		}
		var n = 0;
		var id = 0;
		for (var i = 0; i < ids.length; i++) {
			if (ids[i].checked) {
				n++;
				id = ids[i].value;
			}

		}
		if (n > 1 || id <= 0) {
			alert("请选择一条数据进行查看");
			return;
		}

		addr += "_view.xhtml?entity.id=" + id;
		window.location.href = addr;
}

function reportAll(param) {
	var addr = getUrlStr();
	if (addr.length == 0) {
		alert("当前url不支持此操作");
		return;
	}

	var ids = document.getElementsByName("ids");
	if (ids == null || ids.length == 0) {
		return;
	}
	var idArray = new Array();
	for (var i = 0; i < ids.length; i++) {
		if (ids[i].checked) {
			idArray.push(ids[i].value);
		}

	}
	if (idArray.length == 0) {
		alert("请选择要上报的数据");
		return;
	}

	addr += "_report.xhtml?ids=" + idArray.join(",") + param;
	if (window.confirm("确定是否要上报数据？"))
		window.location.href = addr;
}

function feedback(param) {
		var addr = getUrlStr();
		if (addr.length == 0) {
			alert("当前url不支持此操作");
			return;
		}
		var ids = document.getElementsByName("ids");
		if (ids == null || ids.length == 0) {
			return;
		}
		var n = 0;
		var id = 0;
		for (var i = 0; i < ids.length; i++) {
			if (ids[i].checked) {
				n++;
				id = ids[i].value;
			}
		}
		if (n > 1 || id <= 0) {
			alert("请选择一条数据进行反馈");
			return;
		}
		addr += "_feedback.xhtml?entity.type=" + param +"&entity.id=" + id;
		window.location.href = addr;
}

/**
 * CRUD操作对象,可以设置CRUD的拦截函数
 */
function Operator2() {
	this.formId = "submitForm";// 提交表单
	this.baseUrl = getBaseUrl();// 基本URL
	this.validate = true;
}
Operator2.prototype = {

	beforeCreate : null,
	beforeSave : null,
	beforeUpdate : null,
	beforeView : null,
	beforePrint : null,
	beforeDelete : null,
	beforeDone : null,
	beforeLocation : null,
	/**
	 * 初始化保存页面
	 */
	create : function(space, method, params) {
		if (this.beforeCreate)
			if (!this.beforeCreate())
				return;
		if (validateAddr(this.baseUrl)) {
			if (space == null || space == 'undefined')
				space = getNameSpaceStr();
			if (method == null || method == 'undefined')
				method = "create";
			if (params == null || params == 'undefined')
				params = "";
			var href = this.baseUrl + space + "_" + method + ".xhtml?1=1"
					+ params;
			this.location_dir(href);
		}
	},
	/**
	 * 保存或更新实体
	 */
	save : function(space, method, params) {
		if (formValidator.validate()) {
			if (this.beforeSave)
				if (!this.beforeSave())
					return;
			if (validateAddr(this.baseUrl)) {
				if (space == null || space == 'undefined')
					space = getNameSpaceStr();
				if (method == null || method == 'undefined')
					method = "save";
				if (params == null || params == 'undefined')
					params = "";
				var href = this.baseUrl + space + "_" + method + ".xhtml?1=1"
						+ params;
//						alert(href);
				jQuery("#" + this.formId).attr("action", href).submit();
			}
		}
	},
	/**
	 * 初始化更新页面(适用每条记录后)
	 */
	update : function(id, space, method, params) {
		if (this.beforeUpdate)
			if (!this.beforeUpdate())
				return;
		if (validateAddr(this.baseUrl)) {
			if (space == null || space == 'undefined')
				space = getNameSpaceStr();
			if (method == null || method == 'undefined')
				method = "update";
			if (params == null || params == 'undefined')
				params = "";
			if (params.indexOf("&") <=0) {
				params = "&" + params;
			}
			var href = this.baseUrl + space + "_" + method
					+ ".xhtml?entity.id=" + id + params;
			this.location_dir(href);
		}
	},
	/**
	 * 初始化更新页面(适用每条记录后)
	 */
	view : function(id, space, method, params) {
		if (this.beforeUpdate)
			if (!this.beforeUpdate())
				return;
		if (validateAddr(this.baseUrl)) {
			if (space == null || space == 'undefined')
				space = getNameSpaceStr();
			if (method == null || method == 'undefined')
				method = "view";
			if (params == null || params == 'undefined')
				params = "";
			if (params.indexOf("&") <=0) {
				params = "&" + params;
			}
			var href = this.baseUrl + space + "_" + method
					+ ".xhtml?entity.id=" + id + "&readonly=true" + params;
			this.location_dir(href);
		}
	},
	view2 : function(id, space, method, params) {
		if (this.beforeUpdate)
			if (!this.beforeUpdate())
				return;
		if (validateAddr(this.baseUrl)) {
			if (space == null || space == 'undefined')
				space = getNameSpaceStr();
			if (method == null || method == 'undefined')
				method = "view";
			if (params == null || params == 'undefined')
				params = "";
			if (params.indexOf("&") <=0) {
				params = "&" + params;
			}
			var href = this.baseUrl + space + "_" + method
					+ ".xhtml?entity.id=" + id + "&readonly=true" + params;
			window.open(href);
		}
	},
	print : function(id, space, method, params) {
		if (this.beforeUpdate)
			if (!this.beforeUpdate())
				return;
		if (validateAddr(this.baseUrl)) {
			if (space == null || space == 'undefined')
				space = getNameSpaceStr();
			if (method == null || method == 'undefined')
				method = "print";
			if (params == null || params == 'undefined')
				params = "";
			if (params.indexOf("&") <=0) {
				params = "&" + params;
			}
			var href = this.baseUrl + space + "_" + method
					+ ".xhtml?entity.id=" + id + "&readonly=true" + params;
			//this.location_dir(href);
			window.open(href);
		}
	},
	deleted : function(id, space, method, params) {
		if (this.beforeDelete)
			if (!this.beforeDelete())
				return;
		if (validateAddr(this.baseUrl)) {
			if (space == null || space == 'undefined')
				space = getNameSpaceStr();
			if (method == null || method == 'undefined')
				method = "delete";
			if (params == null || params == 'undefined')
				params = "";
			if (params.indexOf("&") <=0) {
				params = "&" + params;
			}
			var href = this.baseUrl + space + "_" + method + ".xhtml?ids=" + id
					+ params;
			if (window.confirm("确定是否要删除数据？"))
				this.location_dir(href);
		}
	},
	deletedAll : function(space, method, params) {
		if (this.beforeCreate)
			if (!this.beforeCreate())
				return;
		if (validateAddr(this.baseUrl)) {
			if (space == null || space == 'undefined')
				space = getNameSpaceStr();
			if (method == null || method == 'undefined')
				method = "delete";
			if (params == null || params == 'undefined')
				params = "";
			var id = anySelect();
			if (id != "") {
				var href = this.baseUrl + space + "_" + method + ".xhtml?ids="
						+ id + params;
				if (window.confirm("确定是否要删除数据？"))
					this.location_dir(href);
			}
		}
	},
	doneOneSelect : function(space, method, params) {
		if (this.beforeDone)
			if (!this.beforeDone())
				return;
		if (validateAddr(this.baseUrl)) {
			if (space == null || space == 'undefined')
				space = getNameSpaceStr();
			if (method == null || method == 'undefined')
				method = "update";
			if (params == null || params == 'undefined')
				params = "&entity.id=";
			var id = oneSelect();
			if (id != "") {
				var href = this.baseUrl + space + "_" + method + ".xhtml?1=1"
						+ params + id;
				this.location_dir(href);
			}
		}
	},
	doneAnySelect : function(space, method, params) {
		if (this.beforeDone)
			if (!this.beforeDone())
				return;
		if (validateAddr(this.baseUrl)) {
			if (space == null || space == 'undefined')
				space = getNameSpaceStr();
			if (method == null || method == 'undefined')
				method = "delete";
			if (params == null || params == 'undefined')
				params = "&ids=";
			var id = anySelect();
			if (id != "") {
				var href = this.baseUrl + space + "_" + method + ".xhtml?1=1"
						+ params + id;
				this.location_dir(href);
			}
		}
	},
	location : function(url) {
		if (this.beforeLocation)
			if (!this.beforeLocation())
				return;
		if (validateAddr(this.baseUrl)) {
			var href = this.baseUrl + url;
			this.location_dir(href);
		}
	},
	location_confirm : function(url,text){
		if(text==null||text==""||text=="undefined")
			text="确定是否执行本操作？";
		if (window.confirm(text)){
			if (this.beforeLocation)
				if (!this.beforeLocation())
					return;
			if (validateAddr(this.baseUrl)) {
				var href = this.baseUrl + url;
				this.location_dir(href);
			}
		}
	},
	location_dir : function(url) {
		if (this.beforeLocation)
			if (!this.beforeLocation())
				return;
//		alert(url);
		window.location.href = url;
	},
	reload : function() {
		window.location.reload();
	},
	back : function(i) {
		window.history.back(i);
	}
}

function oneSelect() {
	var ids = document.getElementsByName("ids");
	if (ids == null || ids.length == 0) {
		return "";
	}
	var n = 0;
	var id = 0;
	for (var i = 0; i < ids.length; i++) {
		if (ids[i].checked) {
			n++;
			id = ids[i].value;
		}
	}
	if (n > 1 || id <= 0) {
		alert("请选择一条数据");
		return "";
	}
	return id;
}

function anySelect() {
	var ids = document.getElementsByName("ids");
	if (ids == null || ids.length == 0) {
		return "";
	}
	var idArray = new Array();
	for (var i = 0; i < ids.length; i++) {
		if (ids[i].checked) {
			idArray.push(ids[i].value.trim());
		}
	}
	var id = idArray.join(",");
	if (id == null || id == "") {
		alert("请选择一条数据");
		return "";
	}
	return id;
}