// JavaScript Document
function show(){
	var tab=document.getElementById("table_list");
	var tr=tab.getElementsByTagName("tr");
	for(var i=0;i<=tr.length;i++){
	if(i%2==0){
		tr[i].style.backgroundColor="#f9f9f9";
		tr[i].onmouseover=function(){this.style.background="#e1f2f0"};
		tr[i].onmouseout=function(){this.style.background="#f9f9f9"}
		}
		else{
			tr[i].style.backgroundColor="#eef2f2";
			tr[i].onmouseover=function(){this.style.background="#e1f2f0"};
			tr[i].onmouseout=function(){this.style.background="#eef2f2"}
			}
	}
}
window.onload=show;
