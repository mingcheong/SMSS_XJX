
/**
 *表格中列表中全选或不选功能
 *thisObj   主控制复选框
 *toObj  被控制复选框
 */
 function selectAllOrNo(thisObj,toObj){
	 var len=toObj.length;
	 var res=false;
	 if(thisObj.checked==true){
		 res=true;
	 }
	 if(toObj!=null){
		 if(len!=null){
			 for(var i=0;i<len;i++){
				 toObj[i].checked=res;
			 }
		 }else{
			 toObj.checked=res;
		 }
	 }
 }

 /**
  *下拉列表上下排序
  *selectItemMoveUp  往上升
  *selectItemMoveDown  往下降
  *selectItemSwapPosition 私有方法
  */				 
function selectItemMoveUp(selectObj) { 
    var theObjOptions=selectObj.options;
    for(var i=1;i<theObjOptions.length;i++) {
        if( theObjOptions[i].selected && !theObjOptions[i-1].selected ) {
            swapOptionProperties(theObjOptions[i],theObjOptions[i-1]);
        }
    }
} 
function selectItemMoveDown(selectObj) { 
    var theObjOptions=selectObj.options;
    for(var i=theObjOptions.length-2;i>-1;i--) {
        if( theObjOptions[i].selected && !theObjOptions[i+1].selected ) {
            swapOptionProperties(theObjOptions[i],theObjOptions[i+1]);
        }
    }
} 
function selectItemSwapPosition(option1,option2){
    var tempStr=option1.value;
    option1.value=option2.value;
    option2.value=tempStr;
    tempStr=option1.text;
    option1.text=option2.text;
    option2.text=tempStr;
    tempStr=option1.selected;
    option1.selected=option2.selected;
    option2.selected=tempStr;
}



