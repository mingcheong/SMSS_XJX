function addFatherIds(id) {
	if (fatherIds.match(id))
		return;
	else
		fatherIds += id + ",";
}
function setRowSpan(id) {
	var size = jQuery("td[name=" + id + "]").size();
	if (size <= 0)
		return;
	jQuery.each(jQuery("td[name=" + id + "]"), function(i, n) {
				if (i == 0) {
					jQuery(n).attr("rowSpan", size);
				} else {
					jQuery(n).remove();
				}
			})
}
function setRowSpan2(id) {
	var offset = 0;
	if (id.search("-") != -1) {
		offset = parseInt(id.substring(id.search("-") + 1));
	}
	var size = j("td[name=" + id + "]").size() + offset;
	j.each(j("td[name=" + id + "]"), function(i, n) {
				if (i == 0) {
					j(this).attr("rowSpan", size);
				} else {
					j(this).remove();
				}
			})
}
function setColSpan(id) {
	var size = jQuery("th[name=" + id + "]").size();
	jQuery.each(jQuery("th[name=" + id + "]"), function(i, n) {
				if (i == 0) {
					jQuery(n).attr("colspan", size);
				} else {
					jQuery(n).remove();
				}
			})
}
function setTrRowSpan(id) {
	var size = j("tr[name=" + id + "]").size();
	j.each(j("tr[name=" + id + "]"), function(i, n) {
				if (i == 0) {
					j(this).attr("rowSpan", size);
				} else {
					j(this).remove();
				}
			})
}
function setUpcaseDate(data) {
	var year = data.substring(0, 4);
	var month = data.substring(5, 7);
	var year_cn = "";
	var month_cn = "";
	for (var i = 0; i < year.length; i++) {
		if (year.substring(i, i + 1) == "0") {
			year_cn += "〇";
		} else if (year.substring(i, i + 1) == "1") {
			year_cn += "一";
		} else if (year.substring(i, i + 1) == "2") {
			year_cn += "二";
		} else if (year.substring(i, i + 1) == "3") {
			year_cn += "三";
		} else if (year.substring(i, i + 1) == "4") {
			year_cn += "四";
		} else if (year.substring(i, i + 1) == "5") {
			year_cn += "五";
		} else if (year.substring(i, i + 1) == "6") {
			year_cn += "六";
		} else if (year.substring(i, i + 1) == "7") {
			year_cn += "七";
		} else if (year.substring(i, i + 1) == "8") {
			year_cn += "八";
		} else if (year.substring(i, i + 1) == "9") {
			year_cn += "九";
		}
	}
	if (month == 1) {
		month_cn = "一";
	} else if (month == 2) {
		month_cn = "二";
	} else if (month == 3) {
		month_cn = "三";
	} else if (month == 3) {
		month_cn = "三";
	} else if (month == 4) {
		month_cn = "四";
	} else if (month == 5) {
		month_cn = "五";
	} else if (month == 6) {
		month_cn = "六";
	} else if (month == 7) {
		month_cn = "七";
	} else if (month == 8) {
		month_cn = "八";
	} else if (month == 9) {
		month_cn = "九";
	} else if (month == 10) {
		month_cn = "十";
	} else if (month == 11) {
		month_cn = "十一";
	} else if (month == 12) {
		month_cn = "十二";
	}

	if (get("data_cn"))
		get("data_cn").innerHTML = year_cn + "年" + month_cn + "月";
}
function changeUpcase(num) {
	switch (num) {
		case 1 : {
			return "一";
			break;
		}
		case 2 : {
			return "二";
			break;
		}
		case 3 : {
			return "三";
			break;
		}
		case 4 : {
			return "四";
			break;
		}
		case 5 : {
			return "五";
			break;
		}
		case 6 : {
			return "六";
			break;
		}
		case 7 : {
			return "七";
			break;
		}
		case 8 : {
			return "八";
			break;
		}
		case 9 : {
			return "九";
			break;
		}
		case 10 : {
			return "十";
			break;
		}
		default :
			return "再";
	}
}
function setFormUrl(formId, url) {
	jQuery("#" + formId).attr("action", url);
}
function goFormUrl(formId, url) {
	jQuery("#" + formId).attr("action", url).submit();
}
function loadTable(formId, pageNo) {
	jQuery("#pageNo").val(pageNo);
	jQuery("#" + formId).submit();
}
function goUrl(url, target) {
	if (target != null && target != undefined)
		window.open(url, target);
	else
		window.location.href = url;
}
function getDateString() {
	var year = getYear();
	var month = getMonth();
	var day = getDate();
	return year + "-" + month + "-" + day;
}
function getYear() {
	var date = new Date();
	return date.getYear();
}
function getMonth() {
	var date = new Date();
	var month = date.getMonth() + 1;
	return month < 10 ? "0" + month : month;
}
function getDay() {
	var date = new Date();
	var day = date.getDay();
	return day;
}
function getDate() {
	var date = new Date();
	var day = date.getDate();
	return day < 10 ? "0" + day : day;
}
function getNextYearList(num) {
	var year = getYear();
	for (var i = 0; i < num; i++) {
		var _year = year + i;
		jQuery("select[rel='nextYearList']").append("<option value='" + _year
				+ "'>" + _year + "</option>");
	}
}
function changeTable(id) {
	jQuery("div[name='table_opt']").hide();
	jQuery("#" + id).show();
	// jQuery("#"+id+" ul li span:eq(0)").click();
}
// 获取统计图表的dataXML,x_coor作为固定轴，y_coor作为替换轴,rel作为标志
function makeGraphicsString(flag, xName, yName, x_y_title) {
	var x_arr = jQuery.makeArray(jQuery("th[rel='x_coor']"));// 获取固定轴数组，是th单元格
	var title = x_y_title == null ? jQuery("td[rel='title_" + flag + "']")
			.text().trim() : x_y_title;// 获取标题
	var str = "<?xml version='1.0' encoding='UTF-8' ?>";
	str += "<graph caption='"
			+ title
			+ "' xAxisName='"
			+ xName
			+ "' yAxisName='"
			+ yName
			+ "' rotateYAxisName='0' showNames='1' decimalPrecision='0' formatNumberScale='0' baseFont='宋体' baseFontSize='14' palette='10' useRoundEdges='1'>";
	jQuery.each(jQuery("td[rel='" + flag + "']"), function(i, n) {
				for (var j = 0; j < x_arr.length; j++) {
					if (i == j)
						str += "<set name='" + jQuery(x_arr[j]).text().trim()
								+ "' value='" + jQuery(n).text().trim()
								+ "' color='AFD8F8' />";
				}
			});
	return str += "</graph>";
}
// 获取统计图表的dataXML,x_coor作为固定轴，y_coor作为替换轴,rel2作为标志
function makeGraphicsString2(flag, xName, yName, x_y_title) {
	var x_arr = jQuery.makeArray(jQuery("td[rel2='x_coor']"));// 获取固定轴数组，是td单元格
	var title = x_y_title == null ? jQuery("td[rel2='title_" + flag + "']")
			.text().trim() : x_y_title;// 获取标题
	var str = "<?xml version='1.0' encoding='UTF-8' ?>";
	str += "<graph caption='"
			+ title
			+ "' xAxisName='"
			+ xName
			+ "' yAxisName='"
			+ yName
			+ "' rotateYAxisName='0' showNames='1' decimalPrecision='0' formatNumberScale='0' baseFont='宋体' baseFontSize='14' palette='10' useRoundEdges='1'>";
	jQuery.each(jQuery("td[rel2='" + flag + "']"), function(i, n) {
				for (var j = 0; j < x_arr.length; j++) {
					if (i == j)
						str += "<set name='" + jQuery(x_arr[j]).text().trim()
								+ "' value='" + jQuery(n).text().trim()
								+ "' color='AFD8F8' />";
				}
			});
	return str += "</graph>";
}
// 统计列颜色
var colorArray = new Array("AFD8F8", "F6BD0F", "8BBA00", "FF8E46", "008E8E",
		"D64646", "8E468E", "588526", "B3AA00", "008ED6", "9D080D", "A186BE",
		"A186BE", "A186BE", "A186BE");
function makeGraphicsString3(flag, xName, yName, title) {
	var xcol = "graphicsTd_0";
	var arr = flag.split(",");
	var str = "";
	if (arr.length > 0) {
		// 构建xml头
		str += "<?xml version='1.0' encoding='UTF-8' ?>";
		str += "<graph caption='"
				+ title
				+ "' xAxisName='"
				+ xName
				+ "' yAxisName='"
				+ yName
				+ "' rotateYAxisName='0' showNames='1' decimalPrecision='0' formatNumberScale='0' baseFont='宋体' baseFontSize='14' palette='10' useRoundEdges='1'>";

		// 获取X坐标上的数据
		var xtds = jQuery("td[rel='" + xcol + "']");
		str += "<categories font='Arial' fontSize='12' fontColor='000000'>";
		jQuery.each(jQuery(xtds), function(i, n) {
					str += "<category name='" + jQuery(n).text().trim()
							+ "' />";
				});
		str += "</categories>";

		// 每个对象显示数据量
		for (var i = 0; i < arr.length; i++) {
			var dateTds = jQuery("td[rel='" + arr[i] + "']");
			var name = jQuery("#dateLabel_" + arr[i].split("_")[1]).text()
					.trim();// 获取每列统计名称
			var color = colorArray[i];// 获取每列颜色
			str += "<dataset seriesname='" + name + "' color='" + color + "'>";
			jQuery.each(jQuery(dateTds), function(i, n) {
						str += "<set value='" + jQuery(n).text().trim()
								+ "' />";
					});
			str += "</dataset>";
		}
		str += "</graph>";
	}
	return str;
}
// 渲染图表横向渲染
function makeGraphics(flvId, width, height, flash, flag, xName, yName,
		x_y_title) {
	var data = makeGraphicsString(flag, xName, yName, x_y_title);
	var chart = new FusionCharts(
			"/street/resources/default/js/Charts/" + flash, flvId + "_flv",
			width, height);
	chart.setDataXML(data);
	chart.render(flvId);
}
// 渲染图表纵向渲染
function makeGraphics2(flvId, width, height, flash, flag, xName, yName,
		x_y_title) {
	var data = makeGraphicsString2(flag, xName, yName, x_y_title);
	var chart = new FusionCharts(
			"/street/resources/default/js/Charts/" + flash, flvId + "_flv",
			width, height);
	chart.setDataXML(data);
	chart.render(flvId);
}
function makeGraphics3(flvId, width, height, flash, xName, yName, title) {
	// if(beforeMakeGraphics)
	// if (!beforeMakeGraphics())
	// return;
	var flag = setCheckboxValue("dateCol");
	if (typeof(flag) == 'boolean' && !flag) {
		return;
	}
	var data = makeGraphicsString3(flag, xName, yName, title);
	var chart = new FusionCharts(
			"/street/resources/default/js/Charts/" + flash, flvId + "_flv",
			width, height);
	chart.setDataXML(data);
	chart.render(flvId);
}

function showQueryPanel() {
	jQuery("#queryTab").hide();
	jQuery("#queryTabHide").show();
}
function hideQueryPanel() {
	jQuery("#queryTab").show();
	jQuery("#queryTabHide").hide();
}
// 提交表单
function submitCreate(id, url) {
	var formId = "submitForm";
	if (id != null && id != "")
		formId = id;
	if (formValidator.validate()) {
		jQuery("#" + formId).attr("action", url).submit();
	}
}

/**
 * 序列化多选框字符串
 * 
 * @param {}
 *            checkboxName
 * @param {}
 *            hiddenId
 */
function setCheckboxValue(checkboxName, hiddenId, content, flag) {
	var content_x = "请至少选择一项";
	if (content != null && content != "undefined" && content != "")
		content_x = content;
	var ids = document.getElementsByName(checkboxName);
	if (ids == null || ids.length == 0) {
		return false;
	}
	var idArray = new Array();
	for (var i = 0; i < ids.length; i++) {
		if (ids[i].checked) {
			idArray.push(ids[i].value);
		}
	}
	if (!flag) {
		if (idArray.length == 0) {
			alert(content_x);
			return false;
		}
	}
	var addr = idArray.join(",");
	if (hiddenId == null || hiddenId == 'undefined' || hiddenId == '') {
		return addr;
	} else {
		if (addr != "" && addr != "false")
			jQuery("#" + hiddenId).val(addr);
		return true;
	}
}
/**
 * 导出EXCEL
 * 
 * @param {}
 *            id
 * @param {}
 *            tabname
 */
function cellExcel(id, tabname) {
	if (id == null || id == 'undefined')
		id = "heightLightTable";
	if (tabname == null || tabname == 'undefined')
		tabname = "Excel表格";
	var oControlRange = document.body.createControlRange();
	oControlRange.add(document.getElementById(id), 0);
	oControlRange.select();
	document.execCommand('Underline');
	document.execCommand("unlink");
	document.execCommand('UnBookmark');
	document.execCommand("Copy");
	document.execCommand("Undo");
	try {
		var ExApp = new ActiveXObject("Excel.Application");
		ExApp.Caption = tabname;
		ExApp.StandardFont = '宋体';
		var ExWBk = ExApp.workbooks.add();
		var ExWSh = ExWBk.worksheets(1);
		ExApp.DisplayAlerts = false;
		ExApp.visible = true;
		ExWBk.worksheets(1).Paste;
	} catch (e) {
		alert("请检查Microsoft Excel软件有无安装或浏览器ActiveX是否被禁止！")
	} finally {
	}
}
/**
 * 文件下载
 * 
 * @param {}
 *            path
 * @param {}
 *            name
 */
function loadFile(path, name) {
	if (document.getElementById("factName"))
		document.getElementById("factName").value = name;
	if (document.getElementById("fileName"))
		document.getElementById("fileName").value = path;
	if (document.getElementById("download")) {
		var obj = document.getElementById("download");
		obj.submit();
	}
}

function CheckIDCard(StrNumber) {
	// 判断身份证号码格式函数
	// 公民身份号码是特征组合码，
	// 排列顺序从左至右依次为：六位数字地址码，八位数字出生日期码，三位数字顺序码和一位数字校验码

	// 身份证号码长度判断
	if (StrNumber.length < 15 || StrNumber.length == 16
			|| StrNumber.length == 17 || StrNumber.length > 18) {
		CheckIDCard = false;
	}

	// 身份证号码最后一位可能是超过100岁老年人的X
	// 所以排除掉最后一位数字进行数字格式测试
	// 全部换算成17位数字格式

	var Ai;
	if (StrNumber.length == 18) {
		Ai = StrNumber.substring(0, 17);
	} else {
		Ai = StrNumber.substring(0, 6) + "19" + StrNumber.substring(6, 9);
	}

	if (IsNumeric(Ai) == false) {
		return false;
	}

	var strYear, strMonth, strDay, strBirthDay;
	strYear = parseInt(Ai.substring(Ai, 6, 4));
	strMonth = parseInt(Ai.substring(Ai, 10, 2));
	strDay = parseInt(Ai.substring(Ai, 12, 2));

	if (IsValidDate(strYear, strMonth, strDay) == false) {
		return false;
	}

	var arrVerifyCode = new Array("1", "0", "x", "9", "8", "7", "6", "5", "4",
			"3", "2");
	var Wi = new Array(7, 9, 10, 5, 8, 4, 2, 1, 6, 3, 7, 9, 10, 5, 8, 4, 2);

	var i, TotalmulAiWi = 0;
	for (i = 0; loop < 16; loop++) {
		TotalmulAiWi = TotalmulAiWi + parseInt(Ai.substring(i + 1, 1)) * Wi[i];
	}

	var modValue = TotalmulAiWi % 11;
	var strVerifyCode = arrVerifyCode[modValue];

	Ai = Ai & strVerifyCode;

	if ((StrNumber.length == 18) && (StrNumber != Ai)) {
		return false;
	}

}

function IsNumeric(oNum) {
	if (!oNum)
		return false;
	var strP = /^d+(.d+)?$/;
	if (!strP.test(oNum))
		return false;
	try {
		if (parseFloat(oNum) != oNum)
			return false;
	} catch (ex) {
		return false;
	}
	return true;
}

function IsValidDate(psYear, psMonth, psDay) {
	if (psYear == null || psMonth == null || psDay == null) {
		return false;
	}

	var sYear = new String(psYear);
	var sMonth = new String(psMonth);
	var sDay = new String(psDay);

	if (IsValidYear(sYear) == false) {
		return false;
	}

	if (IsValidMonth(sMonth) == false) {
		return false;
	}

	if (IsValidDay(sDay) == false) {
		return false;
	}

	var nYear = parseInt(sYear, 10);
	var nMonth = parseInt(sMonth, 10);
	var nDay = parseInt(sDay, 10);

	if (sYear == "" && sMonth == "" && sDay == "") {
		return true;
	}

	if (sYear == "" || sMonth == "" || sDay == "") {
		return false;
	}

	if (nMonth < 1 || 12 < nMonth) {
		return false;
	}
	if (nDay < 1 || 31 < nDay) {
		return false;
	}

	if (nMonth == 2) {
		if ((nYear % 400 == 0) || (nYear % 4 == 0) && (nYear % 100 != 0)) {
			if ((nDay < 1) || (nDay > 29)) {
				return false;
			}
		} else {
			if ((nDay < 1) || (nDay > 28)) {
				return false;
			}
		}
	} else if ((nMonth == 1) || (nMonth == 3) || (nMonth == 5) || (nMonth == 7)
			|| (nMonth == 8) || (nMonth == 10) || (nMonth == 12)) {
		if ((nDay < 1) || (31 < nDay)) {
			return false;
		}
	} else {
		if ((nDay < 1) || (30 < nDay)) {
			return false;
		}
	}

	return true;
}
function inputFocus(obj) {
	jQuery(obj).addClass("input_foucs");
}
function inputBlur(obj) {
	jQuery(obj).removeClass("input_foucs");
}
function selectAll(name) {
	jQuery.each(jQuery("input[type='checkbox']"), function(i, n) {
				if (jQuery(n).attr("name") == name) {
					jQuery(n).attr("checked", true);
				}
			});
}
function disSelectAll(name) {
	jQuery.each(jQuery("input[type='checkbox']"), function(i, n) {
				if (jQuery(n).attr("name") == name) {
					jQuery(n).attr("checked", false);
				}
			});
}
/**
 * 全选
 * 
 * @param {}
 *            obj
 * @param {}
 *            name
 */
function toggleSelectAll(obj, name) {
	var bool = obj.checked;
	jQuery.each(jQuery("input[type='checkbox']"), function(i, n) {
				if (jQuery(n).attr("name") == name) {
					jQuery(n).attr("checked", bool);
				}
			});
}
function toggleSelectAll2(obj, flag) {
	var bool = obj.checked;
	jQuery.each(jQuery("input[type='checkbox']"), function(i, n) {
				if (jQuery(n).attr("flag") == flag) {
					jQuery(n).attr("checked", bool);
				}
			});
}
/**
 * 反选
 * 
 * @param {}
 *            name
 */
function toggleSelectAllReverse(name) {
	jQuery.each(jQuery("input[type='checkbox']"), function(i, n) {
				if (jQuery(n).attr("name") == name) {
					if (jQuery(n).attr("checked") == true)
						jQuery(n).attr("checked", false);
					else
						jQuery(n).attr("checked", true);
				}
			});
}
/**
 * 格式化小数，能去掉多余的0
 * 
 * @param {}
 *            Num1 目标小数
 * @param {}
 *            Num2 小数位数
 * @return {Number}
 */
function formatNum(Num1, Num2) {
	if (isNaN(Num1) || isNaN(Num2)) {
		return (0);
	} else {
		Num1 = Num1.toString();
		Num2 = parseInt(Num2);
		if (Num1.indexOf('.') == -1) {
			return (Num1);
		} else {
			var b = Num1.substring(0, Num1.indexOf('.') + Num2 + 1);
			var c = Num1.substring(Num1.indexOf('.') + Num2 + 1, Num1
							.indexOf('.')
							+ Num2 + 2);
			if (c == "") {
				return (b);
			} else {
				if (parseInt(c) < 5) {
					return (b);
				} else {
					return ((Math.round(parseFloat(b) * Math.pow(10, Num2)) + Math
							.round(parseFloat(Math.pow(0.1, Num2).toString()
									.substring(
											0,
											Math.pow(0.1, Num2).toString()
													.indexOf('.')
													+ Num2 + 1))
									* Math.pow(10, Num2))) / Math.pow(10, Num2));
				}
			}
		}
	}
}
function show(id) {
	jQuery("#" + id).toggle();
}
function hide(id) {
	jQuery("#" + id).hide();
}

function trim(str) { // 删除左右两端的空格
	return str.replace(/(^\s*)|(\s*$)/g, "");
}
function ltrim(str) { // 删除左边的空格
	return str.replace(/(^\s*)/g, "");
}
function rtrim(str) { // 删除右边的空格
	return str.replace(/(\s*$)/g, "");
}

function getTopWidth() {
	return document.body.clientWidth;
}

function getTopHeight() {
	return document.body.clientHeight;
}

function getCurrentWidth() {
	return document.body.width;
}
function showTitle(obj) {
	alert(jQuery(obj).attr("title"));
}

/**
 * 表格效果JS
 * 
 * @param {}
 *            func
 */
function onloadEvent(func) {
	var one = window.onload
	if (typeof window.onload != 'function') {
		window.onload = func
	} else {
		window.onload = function() {
			one();
			func();
		}
	}
}
/**
 * 表格效果JS
 * 
 * @param {}
 *            func
 */
function showtable() {
	var tableid = 'table_list'; // 表格的id
	var overcolor = '#e1f2f0'; // 鼠标经过颜色
	var color1 = '#f9f9f9'; // 第一种颜色
	var color2 = '#eef2f2'; // 第二种颜色
	var tablename = document.getElementById(tableid)
	if (tablename == null || tablename == 'undefined') {
		return;
	}
	var tr = tablename.getElementsByTagName("tr")
	for (var i = 1; i < tr.length; i++) {
		tr[i].onmouseover = function() {
			this.style.backgroundColor = overcolor;
		}
		tr[i].onmouseout = function() {
			if (this.rowIndex % 2 == 0) {
				this.style.backgroundColor = color1;
			} else {
				this.style.backgroundColor = color2;
			}
		}
		if (i % 2 == 0) {
			tr[i].className = "color1";
		} else {
			tr[i].className = "color2";
		}
	}
}
// 首页链接
function goIndex() {
	window.parent.mainFrame.location.href = "loadWorkSpaceContent.xhtml";
	window.parent.leftFrame.location.href = "loadleftWorkSpace.xhtml";
}
function goIndex() {
	window.parent.mainFrame.location.href = "loadWorkSpaceContent.xhtml";
	window.parent.leftFrame.location.href = "loadleftWorkSpace.xhtml";
}

/**
 * 表格隔行变换颜色
 * 
 * @param {}
 *            id
 * @param {}
 *            j
 */
function showtable(id, j) {
	var tableid = id; // 表格的id
	var overcolor = '#e1f2f0'; // 鼠标经过颜色
	var color1 = '#f9f9f9'; // 第一种颜色
	var color2 = '#eef2f2'; // 第二种颜色
	var tablename = document.getElementById(tableid);
	var tr = tablename.getElementsByTagName("tr");
	for (var i = j; i < tr.length; i++) {
		tr[i].onmouseover = function() {
			this.style.backgroundColor = overcolor;
		}
		tr[i].onmouseout = function() {
			if (this.rowIndex % 2 == 0) {
				this.style.backgroundColor = color1;
			} else {
				this.style.backgroundColor = color2;
			}
		}
		if (i % 2 == 0) {
			tr[i].style.backgroundColor = color1;
		} else {
			tr[i].style.backgroundColor = color2;
		}
	}
}
function beforeForceUpload(id,flag){
	if(flag){
		jQuery("#checkbox_"+id).attr("checked",true);
	}else{
		jQuery("#checkbox_"+id).attr("checked",false);
	}
}
//强制上传文件，如果没有新文件的话
function forceUpload(id,file){
	if(file.length==null || file=="" || file=="undefined"){
		jQuery("#forceUpload_"+id).val(false);
		beforeForceUpload(id,false);
	}else{
		beforeForceUpload(id,true);
	}
}
/**
 * 验证textarea长度
 */
function isNotMax(oTextArea){
	return oTextArea.value.length!=oTextArea.getAttribute("maxlength");
};

//显示，隐藏查询面板
function toggleQueryPanel() {
	if (jQuery("#J_SearchBoxToggle").attr("state") == "show") {
		jQuery("#queryTable").hide();
		jQuery("#J_SearchBoxToggle").attr("state", "hide").css(
				"background-position", "0 0px");
	} else {
		jQuery("#queryTable").show();
		jQuery("#J_SearchBoxToggle").attr("state", "show").css(
				"background-position", "0 -80px");
	}
}